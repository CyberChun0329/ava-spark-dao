const HEX32 = /^0x[\da-f]{64}$/i;
const ADDRESS = /^0x[\da-f]{40}$/i;
const DATA = /^0x(?:[\da-f]{2})*$/i;
const UINT = /^(0|[1-9]\d*)$/;
const KEY = 'ava-workbench:queue:v1';
const STATUSES = new Set(['unknown', 'pending', 'mismatch', 'reverted', 'orphaned', 'confirmed', 'rejected', 'unavailable']);
const TERMINAL = new Set(['confirmed', 'reverted', 'rejected', 'mismatch']);
const same = (a, b) => typeof a === 'string' && typeof b === 'string' && a.toLowerCase() === b.toLowerCase();
const copy = value => JSON.parse(JSON.stringify(value));
function freeze(value) {
  if (value && typeof value === 'object') { Object.values(value).forEach(freeze); Object.freeze(value); }
  return value;
}
function canonical(value) {
  if (typeof value === 'string') return /^0x[\da-f]*$/i.test(value) ? value.toLowerCase() : value;
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === 'object') return Object.fromEntries(Object.keys(value).sort().filter(k => value[k] !== undefined).map(k => [k, canonical(value[k])]));
  return value;
}
const equal = (a, b) => JSON.stringify(canonical(a)) === JSON.stringify(canonical(b));
const semantic = p => ({ version:p.version, operationVersion:p.operationVersion, appId:p.appId, workflowKey:p.workflowKey, operationId:p.operationId, account:p.account, roleKey:p.roleKey, authority:p.authority, input:p.input, call:p.call, chain:p.chain });
function includesInput(actual, requested) {
  if (requested === '' || requested == null) return actual === undefined || equal(actual,requested);
  if (Array.isArray(requested)) return Array.isArray(actual) && requested.length === actual.length && requested.every((v,i) => includesInput(actual[i],v));
  if (typeof requested === 'object') return actual && typeof actual === 'object' && Object.keys(requested).every(k => includesInput(actual[k],requested[k]));
  if (typeof requested === 'number') return String(requested) === String(actual);
  return equal(actual,requested);
}
export function transactionIdentityKey(record) {
  const locator = record.locator ?? record;
  return JSON.stringify(canonical({ localId:locator.localId, appId:locator.appId, workflowKey:locator.workflowKey, operationId:locator.operationId, operationVersion:locator.operationVersion, account:locator.account, roleKey:locator.roleKey, authority:locator.authority, input:locator.input, call:locator.call, chain:locator.chain, hash:record.hash }));
}
function validPrepared(p, request) {
  if (!p || p.version !== 1 || p.operationVersion !== 1 || !HEX32.test(p.appId ?? '') || !ADDRESS.test(p.account ?? '') || typeof p.operationId !== 'string' || !p.operationId || !p.input || typeof p.input !== 'object' || Array.isArray(p.input)
    || !ADDRESS.test(p.call?.to ?? '') || !DATA.test(p.call?.data ?? '') || !UINT.test(p.call?.value ?? '') || !Number.isSafeInteger(p.chain?.chainId) || p.chain.chainId <= 0 || !HEX32.test(p.chain.genesisHash ?? '')
    || !UINT.test(p.asOf?.blockNumber ?? '') || !HEX32.test(p.asOf?.blockHash ?? '') || !UINT.test(p.asOf?.timestamp ?? '')
    || (p.workflowKey !== undefined && !HEX32.test(p.workflowKey)) || (request.workflowKey !== undefined && !same(p.workflowKey,request.workflowKey))
    || !same(p.appId,request.appId) || !same(p.account,request.account) || p.operationId !== request.operationId || !includesInput(p.input,request.input) || (request.roleKey && !same(p.roleKey,request.roleKey))) throw new Error('Invalid prepared operation');
  if (p.authority && request.roleKey && !same(p.authority.roleKey,request.roleKey)) throw new Error('Prepared authority mismatch');
}
/** Storage follows the synchronous localStorage interface. Only public locators and status/hash are retained. */
export function createPublicQueue({ storage = globalThis.localStorage, key = KEY, limit = 100 } = {}) {
  if (!storage || typeof storage.getItem !== 'function' || typeof storage.setItem !== 'function') throw new Error('Public queue storage is required');
  if (!Number.isSafeInteger(limit) || limit < 1) throw new Error('Invalid queue limit');
  function list() {
    const raw = storage.getItem(key); if (!raw) return [];
    const items = JSON.parse(raw); if (!Array.isArray(items)) throw new Error('Invalid public queue');
    return items;
  }
  function put(record) {
    const items = list(); const index = items.findIndex(x => x.locator.localId === record.locator.localId);
    const l = record.locator;
    const locator = {version:l.version,localId:l.localId,appId:l.appId,operationId:l.operationId,operationVersion:l.operationVersion,account:l.account,
      ...(l.workflowKey !== undefined ? {workflowKey:l.workflowKey} : {}), ...(l.roleKey ? {roleKey:l.roleKey} : {}), ...(l.authority ? {authority:{roleKey:l.authority.roleKey,authorityId:l.authority.authorityId}} : {}),
      input:copy(l.input),call:{to:l.call.to,data:l.call.data,value:l.call.value},chain:{chainId:l.chain.chainId,genesisHash:l.chain.genesisHash},createdAt:l.createdAt};
    const conflict = record.recoveryConflict;
    const safe = { locator, status:record.status, ...(record.hash ? {hash:record.hash} : {}),
      ...(HEX32.test(conflict?.hash ?? '') && STATUSES.has(conflict.status) ? {recoveryConflict:{hash:conflict.hash,status:conflict.status}} : {}), oldContext:!!record.oldContext };
    if (index < 0) {
      while (items.length >= limit) { const removable = items.findIndex(x => TERMINAL.has(x.status)); if (removable < 0) throw new Error('Public queue is full'); items.splice(removable,1); }
      items.push(safe);
    } else items[index] = safe;
    storage.setItem(key, JSON.stringify(items));
    return copy(safe);
  }
  return { list, put };
}
export function createWorkbenchController({ postJson, getContext, getProvider, storage, queue = createPublicQueue({storage}), onRecord, validatePrepared, newId = () => globalThis.crypto.randomUUID() }) {
  let draft, generation = 0, busy = false;
  const observations = new Map(), recoveries = new Map();
  function contextChanged() { generation++; draft = undefined; }
  function contextMatches(p, allowDefault = false) {
    const c = getContext();
    return !!c && same(c.appId,p.appId) && same(c.account,p.account) && c.chainId === p.chain.chainId && same(c.genesisHash,p.chain.genesisHash) && (c.workflowKey === undefined ? (p.workflowKey === undefined || allowDefault) : same(c.workflowKey,p.workflowKey));
  }
  function emit(record) { queue.put(record); onRecord?.(copy(record)); return record; }
  async function checkedPrepare(request) {
    const p = await postJson('/console/operations/prepare', copy(request));
    validPrepared(p,request);
    if (validatePrepared) await validatePrepared(p,request);
    return p;
  }
  async function prepare(request) {
    contextChanged(); const turn = generation;
    const req = copy(request);
    if (!HEX32.test(req.appId ?? '') || !ADDRESS.test(req.account ?? '') || typeof req.operationId !== 'string' || !req.operationId || !req.input || typeof req.input !== 'object' || Array.isArray(req.input) || (req.roleKey && !HEX32.test(req.roleKey)) || (req.workflowKey !== undefined && !HEX32.test(req.workflowKey))) throw new Error('Invalid operation request');
    const p = await checkedPrepare(req);
    const legacyDefault = req.workflowKey === undefined && getContext()?.workflowKey === undefined;
    if (turn !== generation || !contextMatches(p,legacyDefault)) throw new Error('Context changed');
    draft = { request:freeze(req), prepared:freeze(copy(p)), legacyDefault };
    return draft.prepared;
  }
  async function submit() {
    if (busy || !draft) throw new Error('No prepared operation');
    busy = true; const {request,prepared:p,legacyDefault} = draft, turn = generation, provider = getProvider();
    try {
      if (!provider || !contextMatches(p,legacyDefault)) throw new Error('Context changed');
      const fresh = await checkedPrepare(request);
      if (turn !== generation || !contextMatches(p,legacyDefault) || !equal(semantic(p),semantic(fresh))) { if (turn === generation) draft = undefined; throw new Error('Preview changed'); }
      const accounts = await provider.request({method:'eth_accounts'});
      const chainId = await provider.request({method:'eth_chainId'});
      const genesis = await provider.request({method:'eth_getBlockByNumber',params:['0x0',false]});
      if (turn !== generation || !contextMatches(p,legacyDefault) || !Array.isArray(accounts) || !same(accounts[0],p.account) || typeof chainId !== 'string' || Number(chainId) !== p.chain.chainId || !same(genesis?.hash,p.chain.genesisHash)) throw new Error('Wallet identity mismatch');
      const locator = {version:1, localId:newId(), appId:p.appId, ...(!legacyDefault && p.workflowKey !== undefined ? {workflowKey:p.workflowKey} : {}), operationId:p.operationId, operationVersion:p.operationVersion, account:p.account, ...(request.roleKey ? {roleKey:request.roleKey} : {}), ...(p.authority ? {authority:copy(p.authority)} : {}), input:copy(p.input), call:copy(p.call), chain:copy(p.chain), createdAt:new Date().toISOString()};
      let record = {locator,status:'unknown',oldContext:false};
      if (typeof locator.localId !== 'string' || !locator.localId || queue.list().some(item => item.locator.localId === locator.localId)) throw new Error('Duplicate or invalid local ID');
      emit(record); // A durable attempt exists before any wallet prompt.
      draft = undefined;
      try {
        const hash = await provider.request({method:'eth_sendTransaction',params:[{from:p.account,to:p.call.to,data:p.call.data,value:`0x${BigInt(p.call.value).toString(16)}`}]});
        if (typeof hash === 'string' && HEX32.test(hash)) record = {...record,hash,status:'pending'};
      } catch (error) { if (error?.code === 4001) record = {...record,status:'rejected'}; }
      record.oldContext = turn !== generation || !contextMatches(locator);
      const retained = queue.list().find(item=>item.locator.localId===locator.localId);
      // Recovery may already have proved this attempt while the wallet prompt was open.
      if(retained?.hash) {
        if(record.hash && !same(record.hash,retained.hash)) return emit({...record,locator:retained.locator,recoveryConflict:{hash:retained.hash,status:retained.status},oldContext:retained.oldContext || record.oldContext});
        return emit({...retained,oldContext:retained.oldContext || record.oldContext});
      }
      return emit(record);
    } finally { busy = false; }
  }
  async function requestObservation(record, hash, signal) {
    if (signal?.aborted) throw new Error('Observation cancelled');
    let abort;
    const cancelled = signal && new Promise((_,reject) => { abort = () => reject(new Error('Observation cancelled')); signal.addEventListener('abort',abort,{once:true}); });
    try {
      const pending = postJson('/console/operations/observe',{locator:copy(record.locator),hash}, {signal});
      const result = await (cancelled ? Promise.race([pending,cancelled]) : pending);
      if (signal?.aborted) throw new Error('Observation cancelled');
      return result;
    } finally { if (abort) signal.removeEventListener('abort',abort); }
  }
  async function observe(record, options = {}) {
    if (!HEX32.test(record?.hash ?? '')) throw new Error('Missing transaction hash');
    const retained = queue.list().find(x => x.locator.localId === record.locator?.localId);
    if (!retained || !equal(retained.locator,record.locator) || !retained.hash || !same(retained.hash,record.hash)) throw new Error('Unknown original intent');
    record = {...retained, hash:record.hash};
    const key = transactionIdentityKey(record), turn = {};
    observations.set(key,turn);
    emit({...record,status:'unknown',observation:undefined});
    let next;
    try {
      const observation = await requestObservation(record,record.hash,options.signal);
      if (options.signal?.aborted) throw new Error('Observation cancelled');
      if (!observation || !same(observation.hash,record.hash) || !STATUSES.has(observation.status)) throw new Error('Invalid observation');
      next = {...record,status:observation.status,observation,oldContext:record.oldContext || !contextMatches(record.locator)};
    } catch { next = {...record,status:'unavailable',observation:undefined,oldContext:record.oldContext || !contextMatches(record.locator)}; }
    const latest = queue.list().find(x => x.locator.localId === record.locator.localId);
    if (observations.get(key) !== turn || !latest || transactionIdentityKey(latest) !== key) return copy(latest ?? {...record,status:'unknown',observation:undefined});
    return emit(next);
  }
  async function recover(record, hash, options = {}) {
    if (!HEX32.test(hash ?? '') || (record.hash && !same(record.hash,hash))) throw new Error('Invalid original transaction hash');
    const retained = queue.list().find(x => x.locator.localId === record.locator.localId);
    if (!retained || !equal(retained.locator,record.locator) || (retained.hash && !same(retained.hash,hash))) throw new Error('Unknown original intent');
    if(retained.hash) return observe(retained,options);
    const turn={};recoveries.set(retained.locator.localId,turn);
    let observation;
    try {observation=await requestObservation(retained,hash,options.signal); if(options.signal?.aborted) throw new Error('Observation cancelled');}
    catch {const latest=queue.list().find(x=>x.locator.localId===retained.locator.localId);return recoveries.get(retained.locator.localId)!==turn || latest?.hash ? copy(latest ?? retained) : emit({...retained,status:'unavailable'});}
    if(!observation || !same(observation.hash,hash) || !STATUSES.has(observation.status)) throw new Error('Invalid observation');
    const latest=queue.list().find(x=>x.locator.localId===retained.locator.localId);
    if(recoveries.get(retained.locator.localId)!==turn || latest?.hash) return copy(latest ?? retained);
    // A manually typed hash remains a candidate until the transaction matches.
    if(!['pending','confirmed','reverted'].includes(observation.status)) return emit({...retained,status:'unknown',observation:{...observation,candidateHash:hash}});
    return emit({...retained,hash,status:observation.status,observation,oldContext:retained.oldContext || !contextMatches(retained.locator)});
  }
  return {prepare,submit,observe,recover,contextChanged,list:() => queue.list().map(record => ({...record,oldContext:record.oldContext || !contextMatches(record.locator)}))};
}

let fieldSequence = 0;
const fieldFormats = {
  hash: {pattern:'0[xX][0-9a-fA-F]{64}', hint:'Use 0x followed by exactly 64 hexadecimal digits (32 bytes).'},
  address: {pattern:'0[xX][0-9a-fA-F]{40}', hint:'Use 0x followed by exactly 40 hexadecimal digits (20 bytes).'},
  uint: {pattern:'(?:0|[1-9][0-9]*)', hint:'Use whole decimal digits, including 0, without leading zeros, commas or exponents.'},
};

/** Render finite public operation fields into an existing DOM container. */
export function renderFields(container, fields) {
  const doc = container.ownerDocument;
  function render(target, definitions) {
    const readers = [];
    for (const field of definitions) {
      const id = `ava-field-${++fieldSequence}`, format = fieldFormats[field.type];
      const grouped = field.type === 'group' || field.type === 'list';
      const wrapper = doc.createElement(grouped ? 'fieldset' : 'div');
      const label = doc.createElement(grouped ? 'legend' : 'label'); label.textContent = field.label ?? field.name;
      wrapper.append(label); target.append(wrapper);
      const helpText = [field.help,format?.hint].filter(Boolean).join(' ');
      if (helpText) { const help = doc.createElement('small'); help.id = `${id}-help`; help.textContent = helpText; wrapper.append(help); }
      if (grouped && helpText) wrapper.setAttribute('aria-describedby',`${id}-help`);
      if (field.type === 'group') {
        const read = render(wrapper, field.fields ?? []); readers.push([field.name,read]); continue;
      }
      if (field.type === 'list') {
        const rows = doc.createElement('div'), add = doc.createElement('button');
        add.type = 'button'; add.textContent = `Add ${field.label ?? field.name}`; wrapper.append(rows,add);
        const entries = [];
        const focusRow = entry => entry.row.querySelector('input:not([disabled]), select:not([disabled]), button:not([disabled])')?.focus();
        const numberRows = () => entries.forEach((entry,index) => {
          const name = `${field.label ?? field.name} ${index+1}`;
          entry.legend.textContent = name; entry.remove.setAttribute('aria-label',`Remove ${name}`);
        });
        add.addEventListener('click', () => {
          if (entries.length >= (field.maxItems ?? 100)) return;
          const row = doc.createElement('fieldset'), legend = doc.createElement('legend'), remove = doc.createElement('button');
          row.append(legend);
          rows.append(row); const read = render(row,field.fields ?? []);
          remove.type = 'button'; remove.textContent = 'Remove'; row.append(remove);
          const entry = {row,read,legend,remove}; entries.push(entry); numberRows();
          remove.addEventListener('click', () => {
            const index = entries.indexOf(entry); entries.splice(index,1); row.remove(); add.disabled = false; numberRows();
            const remaining = entries[index] ?? entries.at(-1);
            if (remaining) focusRow(remaining); else add.focus();
          });
          add.disabled = entries.length >= (field.maxItems ?? 100);
          focusRow(entry);
        });
        readers.push([field.name,() => entries.map(entry => entry.read())]); continue;
      }
      let input;
      if (field.type === 'select') {
        input = doc.createElement('select');
        for (const option of field.options ?? []) {
          const el = doc.createElement('option');
          el.value = String(typeof option === 'object' ? option.value : option);
          el.textContent = String(typeof option === 'object' ? option.label ?? option.value : option); input.append(el);
        }
      } else {
        input = doc.createElement('input'); input.type = field.type === 'bool' ? 'checkbox' : 'text';
        if (field.type === 'uint') input.inputMode = 'numeric';
      }
      input.name = field.name;
      input.id = id; label.htmlFor = id;
      input.dataset.fieldType = field.type;
      // Required describes value presence; read() supplies false for unchecked booleans.
      input.required = field.type !== 'bool' && !!field.required;
      if (format) { input.pattern = format.pattern; input.title = format.hint; }
      const error = doc.createElement('small'); error.id = `${id}-error`; error.className = 'field-error'; error.hidden = true;
      input.setAttribute('aria-describedby',`${helpText ? `${id}-help ` : ''}${error.id}`);
      input.addEventListener('invalid', () => {
        error.textContent = input.validity.valueMissing ? 'This field is required.' : input.validity.patternMismatch ? format.hint : input.validationMessage;
        error.hidden = false; input.setAttribute('aria-invalid','true');
      });
      input.addEventListener('input', () => { error.hidden = true; input.removeAttribute('aria-invalid'); });
      if (field.default !== undefined) { if (field.type === 'bool') input.checked = !!field.default; else input.value = String(field.default); }
      label.append(input); wrapper.append(error);
      readers.push([field.name,() => field.type === 'bool' ? input.checked : input.value]);
    }
    return () => Object.fromEntries(readers.map(([name,read]) => [name,read()]));
  }
  function reset() { container.replaceChildren(); read = render(container,fields); }
  let read; reset();
  return {read:() => read(),reset};
}
