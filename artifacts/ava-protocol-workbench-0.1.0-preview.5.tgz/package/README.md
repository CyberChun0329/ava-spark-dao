# @ava-protocol/workbench

Framework-independent browser primitives for the finite AVA workbench HTTP API. The host supplies authenticated `postJson`, the active context, and its EIP-1193 provider. `prepare(request)` returns an immutable preview. `submit()` refreshes it, verifies the full semantic tuple and wallet chain/account/genesis, records a public locator and makes one `eth_sendTransaction` call. The host can provide `validatePrepared` for additional operation-specific intent validation. Hosts that select a workflow should include its `workflowKey` in both the request and active context; the selected key is retained in the public locator and checked during preview refresh and used to flag a different active context on recovery. Existing hosts may omit the selector.

`createPublicQueue` uses localStorage by default; inject a synchronous Storage-compatible adapter in other environments. Only put public on-chain operation input and locators into the queue. Do not pass credentials, signed HTTP envelopes, private material, or private bytes as operation fields. HTTP credentials and material transport belong to the host and are never stored by this package. A full queue rejects new attempts when no terminal record can be evicted.

`list()` restores attempts without sending. An unknown attempt without a hash cannot be automatically retried; when the original hash is known, call `recover(record, originalHash)`. `observe(record)` explicitly requests the canonical transaction result. Both `observe(record, {signal})` and `recover(record, originalHash, {signal})` accept an AbortSignal, including a deadline signal supplied by the host. Aborting or timing out stops the read and does not cancel a wallet transaction; the original intent remains available for another explicit query. If a wallet returns a different hash after manual recovery, the wallet hash becomes the pending attempt and `recoveryConflict` retains the manually recovered hash and its recorded status at the time of the conflict, which may be `unknown` while a refresh is in progress; it is not a current chain observation. Query the wallet hash explicitly to learn its result. A context change during a wallet prompt marks the original attempt `oldContext`; observation remains an explicit action. Logging out should clear host credentials without deleting this public queue.

The transport and wallet are injected, so the package neither stores credentials nor assumes a wallet brand. A successful transaction receipt is evidence of that operation; the server labels separate current readback and can report it unavailable.

An omitted active workflow is not a wildcard for an explicitly selected workflow. Legacy requests without a selector retain the implicit default in their locator; explicit workflow locators require a matching active selection.

## Structured forms

`renderFields(container, descriptors)` returns a value reader and reset function.
Place the container inside a native form and use its normal submit event to apply
browser validation. Hashes, addresses and unsigned integers receive syntax checks;
unsigned integers stay exact decimal strings. Zero values are allowed syntactically,
and `0x` or `0X` prefixes are accepted. The host/service still checks numeric ranges,
record ownership, current permissions and business conditions. Calling `read()`
alone does not validate those conditions.

For a boolean descriptor, `required` means that a boolean value must be present;
unchecked produces explicit `false`. It never forces a user to grant permission
by checking a box. A required list may be empty unless the owning operation rejects
it. The renderer does not infer a minimum number of rows.

Help and inline format errors are associated with the control. Nested groups and
list rows have legends; adding a row focuses its first control, and removing one
focuses a remaining row or the Add button. Hosts supply domain labels and help;
they keep authority checks and explicit wallet confirmation outside this renderer.


## Replacing a preparation

Preparing another operation invalidates the prior preview. A delayed submission
check for the old operation rejects that old action without discarding the newer
preparation. Only one submission may be pending at a time; after it settles, the
host can explicitly confirm the newer preparation. This never resends an earlier
attempt or bypasses its fresh authority and wallet identity checks.
