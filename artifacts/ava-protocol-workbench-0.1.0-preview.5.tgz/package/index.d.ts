export type JsonValue = null | boolean | number | string | JsonValue[] | { [key: string]: JsonValue };
export type PublicInput = { [key: string]: JsonValue };
export interface OperationRequest { appId: string; operationId: string; account: string; workflowKey?: string; roleKey?: string; input: PublicInput }
export interface Call { to: string; data: string; value: string }
export interface ChainIdentity { chainId: number; genesisHash: string }
export interface Authority { roleKey: string; authorityId: string; [key: string]: JsonValue }
export interface PreparedOperation extends OperationRequest {
  version: 1; operationVersion: 1; authority?: Authority; call: Call; chain: ChainIdentity;
  asOf: { blockNumber: string; blockHash: string; timestamp: string }; summary?: string;
}
export interface PublicLocator extends OperationRequest {
  version: 1; localId: string; operationVersion: 1; authority?: Authority; call: Call; chain: ChainIdentity; createdAt: string;
}
export type TransactionStatus = 'unknown' | 'pending' | 'mismatch' | 'reverted' | 'orphaned' | 'confirmed' | 'rejected' | 'unavailable';
export interface Observation { hash: string; status: TransactionStatus; events?: JsonValue[]; readback?: JsonValue; receipt?: JsonValue; readbackUnavailable?: boolean }
export interface TransactionRecord { locator: PublicLocator; status: TransactionStatus; hash?: string; recoveryConflict?: {hash: string; status: TransactionStatus}; oldContext: boolean; observation?: Observation }
export interface Storage { getItem(key: string): string | null; setItem(key: string, value: string): void }
export interface PublicQueue { list(): TransactionRecord[]; put(record: TransactionRecord): TransactionRecord }
export interface Provider { request(args: {method: string; params?: unknown[]}): Promise<unknown> }
export interface WorkbenchContext extends ChainIdentity { appId: string; account: string; workflowKey?: string }
export interface ControllerOptions {
  postJson(path: string, body: unknown, options?: {signal?: AbortSignal}): Promise<unknown>;
  getContext(): WorkbenchContext | undefined;
  getProvider(): Provider | undefined;
  storage?: Storage;
  queue?: PublicQueue;
  onRecord?(record: TransactionRecord): void;
  validatePrepared?(prepared: PreparedOperation, request: OperationRequest): void | Promise<void>;
  newId?(): string;
}
export interface WorkbenchController {
  prepare(request: OperationRequest): Promise<PreparedOperation>;
  submit(): Promise<TransactionRecord>;
  observe(record: TransactionRecord, options?: {signal?: AbortSignal}): Promise<TransactionRecord>;
  recover(record: TransactionRecord, hash: string, options?: {signal?: AbortSignal}): Promise<TransactionRecord>;
  contextChanged(): void;
  list(): TransactionRecord[];
}
export function transactionIdentityKey(record: TransactionRecord | PublicLocator): string;
export function createPublicQueue(options?: {storage?: Storage; key?: string; limit?: number}): PublicQueue;
export function createWorkbenchController(options: ControllerOptions): WorkbenchController;
export interface FieldDescriptor {
  name: string; label: string; type: 'text' | 'hash' | 'address' | 'uint' | 'bool' | 'select' | 'group' | 'list';
  options?: (string | number | {value: string | number; label?: string})[]; fields?: FieldDescriptor[]; required?: boolean;
  default?: string | number | boolean; help?: string; maxItems?: number;
}
export function renderFields(container: HTMLElement, fields: FieldDescriptor[]): {read(): PublicInput; reset(): void};
